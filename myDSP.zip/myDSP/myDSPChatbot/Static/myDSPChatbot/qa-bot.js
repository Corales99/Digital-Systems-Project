var botui = new BotUI('qa-bot');
var question = '';
var answer = 'Thank you!';
var botmessage = 'UWE-DSP-Demo.';
var idx = 0;

talk();


function talk()
{
botui.message
  .bot(botmessage)
  .then(function () {
    return botui.action.button({
      delay: 1000,
      addMessage: false, // so we could have the question in message instead if 'Existing question'
      action: [{
        text: 'New to Peltarion',
        value: 'exist'
      }, {
        text: 'Ask Questions',
        value: 'new'
      }]
    })
}).then(function (res) {
  if(res.value == 'exist') {
    botui.message.human({
      delay: 500,
      content: botmessage
      });
    endsimple();
  } else {
    botui.message.human({
      delay: 500,
      content: res.text
    });
//    todo: should be generated automatically
//easy start with random sentence
    getbotmesssage(question);
    askquestion();
  }
});
}


function getbotmesssage(question) {
    //return bot message based on human messge
    if ( question.toLowerCase().indexOf('thank') !== -1 && idx > 0){
    botmessage = 'Is there anything else I can do for you?';
    }
    else if( question.toLowerCase().indexOf('feature') !== -1 ){
    botmessage = 'We have recorded your feature request, thank you.';
    }
    else{
    getrandomebotmessage()
    }
}

function getrandomebotmessage(){
    listmessages = ['I will try to find an answer for you...','Your question is important for us', 'I may know the answer', 'Hi,', 'great to hear from you.']
    randomidx = Math.floor(Math.random() * 4) + 1
    botmessage = listmessages[randomidx]
}

function simscore(s1,s2){
}

function reconstructsent(s){
}

function generatesent(keywords){
}

function askquestion() {
  botui.message
    .bot({
      delay: 500,
      content: botmessage
    })
    .then(function () {
      return botui.action.text({
        delay: 1000,
        action: {
          size: 30,
          icon: 'check',
          value: question, // show the saved question if any
          placeholder: 'question'
        }
      })
    }).then(function (res) {
      botui.message
        .bot({
          delay: 500,
          content: botmessage
        });

      question = res.value; // save question
      alert('0!');
      return botui.action.button({
        delay: 1000,
        action: [{
          icon: 'check',
          text: 'Confirm',
          value: 'confirm'
        }, {
          icon: 'pencil',
          text: 'Edit',
          value: 'edit'
        }]
      })
    }).then(function (res) {
    alert('1!');
      if(res.value == 'confirm') {
      alert('before end1!');
        end();
//        question = res.value; //haixia
        question = ''
        getbotmesssage(question);
        askquestion();
      } else {
        getbotmesssage(question);
        askquestion();
      }
    });
}

function endsimple() {
  botui.message
    .bot({
      delay: 1000,
      content: 'Welcome to our knowledge center: http://docs.peltarion.com/new/?lang=en'
    });
    idx = 0;
}

function end() {
alert('in end!!!');
$.ajax({type:'post',url:"http://localhost:5555/talk",data:{"question":question},success:function(data){

    data = JSON.parse(data);
    if ('answer' in data.data)
    {
    answer = data.data.answer;
    }

    botui.message
    .bot({
      delay: 1000,
      content: answer
    });
    console.log(data.data);

    }});
    idx = idx + 1;
//    talk();
}
