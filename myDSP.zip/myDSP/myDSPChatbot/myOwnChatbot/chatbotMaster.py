class chatbotMaster(object):
    """
    A conversational dialog chat bot.
    """
    def __init__(self, name, **kwargs):
        self.name = name
    def get_response(self, statement):
        response = self.name + " this is get_response to the statement: " + statement
        return response
    def generate_response(self, statement):
        response = self.name + " generated dummy response to the question: " + statement
        return response